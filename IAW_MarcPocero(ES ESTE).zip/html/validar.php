<?php
session_start();
$usuario=$_POST['usuario'];
$clave=$_POST['clave'];
$conection=mysqli_connect("localhost", "root", "marcpocero", "AP2");
$query="SELECT * FROM usuaris WHERE usuari='$usuario' and contrasenya='$clave'";
$resultados=mysqli_query($conection, $query);
while($row = mysqli_fetch_array($resultados)) {
  $rol=$row['rol'];
}
$_SESSION['rol'] = $rol;
$filas=mysqli_num_rows($resultados);
if ($filas>0) {
    header("location:dashboard.php");
} else {
    echo "Error en la autentificacion";
}
    mysqli_free_result($resultados);
    mysqli_close($conection);
?>
